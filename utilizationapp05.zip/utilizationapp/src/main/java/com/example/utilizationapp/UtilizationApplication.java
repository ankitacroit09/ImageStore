package com.example.utilizationapp;

import java.io.File;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtilizationApplication {

	public static void main(String[] args) {
		
		File directory = new File("\\images\\");
		if (! directory.exists()){
	        directory.mkdir();
	    }

		SpringApplication.run(UtilizationApplication.class);
	}
}
